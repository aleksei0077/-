﻿using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

namespace LightbulbGuessServer
{
    class Program
    {
        // Хранит правильное число, которое нужно угадать
        private static int correctNumber;
        // Флаг, указывающий, что число уже было угадано
        private static bool isGuessed = false;
        // Указывает текущего игрока
        private static int currentPlayer = 1;
        // Количество ходов каждого игрока
        private static int player1MovesNumber = 0;
        private static int player2MovesNumber = 0;
        // Хранит номер победителя
        static int winner = 0;
        // Объект для синхронизации доступа к общим ресурсам
        private static readonly object lockObject = new object();

        public static void Main(string[] args)
        {
            // Создание слушателя TCP на порту 5000
            TcpListener listener = new TcpListener(IPAddress.Any, 5000);
            listener.Start();
            Console.WriteLine("Сервер запущен... Ожидайте подключение игроков.");

            // Принятие первого подключения
            TcpClient client1 = listener.AcceptTcpClient();
            Console.WriteLine("Игрок 1 подключился.");

            // Принятие второго подключения
            TcpClient client2 = listener.AcceptTcpClient();
            Console.WriteLine("Игрок 2 подключился.");

            // Генерация правильного числа
            correctNumber = GenerateCorrectNumber();
            Console.WriteLine($"Загадано число {correctNumber}");

            // Создание потоков для обработки клиентов
            Thread thread1 = new Thread(() => HandleClient(client1, 1, correctNumber));
            thread1.Start();

            Thread thread2 = new Thread(() => HandleClient(client2, 2, correctNumber));
            thread2.Start();

            // Ожидание окончания игры
            while (!isGuessed)
            {
                Thread.Sleep(100);
            }

            Console.WriteLine("Игра завершена.");
            listener.Stop();
            Console.WriteLine("Сервер остановлен.");
            Console.ReadLine();
        }

        // Обработка клиента
        private static void HandleClient(TcpClient client, int playerNumber, int correctNumber)
        {
            NetworkStream stream = client.GetStream();
            StreamReader reader = new StreamReader(stream, Encoding.UTF8);
            StreamWriter writer = new StreamWriter(stream, Encoding.UTF8) { AutoFlush = true };

            // Приветствие игрока
            writer.WriteLine($"Быки и коровы, игрок {playerNumber}!");

            // Основной цикл игры
            while (!isGuessed)
            {
                // Если не текущий игрок, ожидаем его хода
                if (playerNumber != currentPlayer)
                {
                    Thread.Sleep(100);
                    continue;
                }

                // Запрос хода от игрока
                writer.WriteLine("Ваш ход");
                string guess = reader.ReadLine();

                // Проверка формата ответа
                if (!Regex.IsMatch(guess, @"^\d{4}$"))
                {
                    writer.WriteLine("Число должно быть четырехзначным. Попробуйте еще раз.");
                    continue;
                }

                
                int guessedNumber = int.Parse(guess);

                // Обновление счетчика ходов
                if (playerNumber == 1)
                {
                    player1MovesNumber++;
                }
                else
                {
                    player2MovesNumber++;
                }

                // Подсчет "быков" и "коров"
                int bulls = 0, cows = 0;
                for (int i = 0; i < 4; i++)
                {
                    int digitInGuessed = guessedNumber / (int)Math.Pow(10, i) % 10; 
                    int digitInCorrect = correctNumber / (int)Math.Pow(10, i) % 10;

                    if (digitInGuessed == digitInCorrect)
                    {
                        bulls++;
                    }
                    else if (guessedNumber.ToString().IndexOf(digitInCorrect.ToString()) != -1)
                    {
                        cows++;
                    }
                }

                // Отправка результатов подсчета
                writer.WriteLine($"Быки: {bulls}, Коровы: {cows}");

                // Проверка условий победы
                if (bulls == 4)
                {
                    winner = playerNumber;
                    int loser = (playerNumber == 1) ? 2 : 1;
                    //создается переменная, которая получает значение 2, если playerNumber равен 1,
                    //иначе(если playerNumber не равен 1) ей присваивается значение 1.Это условное
                    //присваивание значения переменной в зависимости от условия.

                    writer.WriteLine($"Вы выиграли. Вы угадали число за {(winner == 1 ? player1MovesNumber : player2MovesNumber)} ходов.");
                    Console.WriteLine($"Игрок {winner} выиграл Он угадал число за {(winner == 1 ? player1MovesNumber : player2MovesNumber)} ходов.");

                    writer.WriteLine($"Игрок {loser} проиграл. Число было загадано {correctNumber}.");

                    isGuessed = true;
                }

                // Смена текущего игрока
                currentPlayer = (currentPlayer == 1) ? 2 : 1;
            }

            // Завершение игры для проигравшего
            if (winner > 0 && winner != currentPlayer)
            //Это условие гарантирует, что победителем
            //не является тот игрок, чья очередь сейчас.
            {
                writer.WriteLine($"Вы проиграли. Было загадано число {correctNumber}.");
            }

            // Ожидание закрытия соединения
            Thread.Sleep(5000);
            client.Close();
        }

        // Генерация правильного числа
        private static int GenerateCorrectNumber()
        {
            Random random = new Random();
            int min = 1000; // Минимальное значение для четырехзначного числа
            int max = 9999; // Максимальное значение для четырехзначного числа
            return random.Next(min, max);
        }
    }
}
