﻿using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace BullAndCowsClient
{
    class Program
    {
        static void Main(string[] args)
        {
            // Создание TCP клиента для подключения к серверу
            try
            {
                TcpClient client = new TcpClient();

                
                client.Connect(IPAddress.Loopback, 5000);
                Console.WriteLine("Подключено к серверу.");

                // Получение потока данных для чтения и записи сообщений
                NetworkStream stream = client.GetStream();
                StreamReader reader = new StreamReader(stream, Encoding.UTF8);
                StreamWriter writer = new StreamWriter(stream, Encoding.UTF8) { AutoFlush = true };

                // Чтение приветственного сообщения от сервера
                string welcomeMessage = reader.ReadLine();
                Console.WriteLine(welcomeMessage);

                // Основной цикл игры
                while (true)
                {
                    // Вывод сообщения о начале хода
                    Console.WriteLine("Ожидайте вашего хода");

                    // Чтение ответа от сервера
                    string response = reader.ReadLine();
                    Console.WriteLine(response);

                    // Проверка условия завершения игры
                    if (response.Contains("проиграл") || response.Contains("выиграл"))
                    {
                        Console.WriteLine("Игра завершена");
                        break;
                    }

                    // Запрос у пользователя на ввод числа
                    Console.Write("Введите четырехзначное число: ");
                    string input = Console.ReadLine();

                    // Отправка введенного числа на сервер
                    writer.WriteLine(input);

                    // Чтение ответа от сервера после отправки числа
                    response = reader.ReadLine();
                    Console.WriteLine(response);

                    // Проверка условия завершения игры после каждого хода
                    if (response.Contains("выиграл"))
                    {
                        Console.WriteLine("Игра завершена.");
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                // Вывод информации об ошибке
                Console.WriteLine($"Ошибка: {ex.Message}");
            }

            // Ожидание нажатия клавиши пользователем перед выходом из программы
            Console.ReadLine();
        }
    }
}
